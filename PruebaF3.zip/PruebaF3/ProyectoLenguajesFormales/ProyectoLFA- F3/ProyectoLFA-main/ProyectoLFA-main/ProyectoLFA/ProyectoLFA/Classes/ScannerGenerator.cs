﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyectoLFA.Classes;
using Action = System.Action;

namespace ProyectoLFA.Classes
{
    class ScannerGenerator
    {
        public static string[] GetSourceCode(ET tree)
        {
            DFA automata = new DFA(tree); // Crea un autómata finito determinista.
            TransitionT transitions = new TransitionT(automata.states); // Obtiene transiciones del autómata.

            // Código fuente y líneas de código para trabajar con recursos externos.
            string sourceCode = Classes.Resource1.Program1;
            string LineasdeCodigo = Classes.Resource1.Final1;

            // Obtiene varios valores del árbol, como colores, tokens, etc.
            string TitleColor = getColor();
            string Character_Token_First = getFistPositionsWithCharacters(tree.tokens);
            string Character_Token_Last = getLastPositionsWithCharacters(tree.tokens);
            string Reservadas_Values = getReservedValues(tree.actions);
            string TokensConReferencia = getReferences(tree.actionReference);
            string Estados_Aceptacion = getAcceptedStates(transitions);
            string States = getTransitions(transitions, tree.sets);

            // Sustituye valores de marcadores por los valores reales.
            sourceCode = sourceCode.Replace("</TitleColor>", TitleColor);
            sourceCode = sourceCode.Replace("</FirstPos>", Character_Token_First);
            sourceCode = sourceCode.Replace("</LastPos>", Character_Token_Last);
            sourceCode = sourceCode.Replace("</Reservadas>", Reservadas_Values);
            sourceCode = sourceCode.Replace("</Referencias>", TokensConReferencia);
            sourceCode = sourceCode.Replace("</States>", States);
            sourceCode = sourceCode.Replace("</Aceptacion>", Estados_Aceptacion);

            LineasdeCodigo = LineasdeCodigo.Replace("</TitleColor>", TitleColor);
            LineasdeCodigo = LineasdeCodigo.Replace("</FirstPos>", Character_Token_First);
            LineasdeCodigo = LineasdeCodigo.Replace("</LastPos>", Character_Token_Last);
            LineasdeCodigo = LineasdeCodigo.Replace("</Reservadas>", Reservadas_Values);
            LineasdeCodigo = LineasdeCodigo.Replace("</Referencias>", TokensConReferencia);
            LineasdeCodigo = LineasdeCodigo.Replace("</States>", States);
            LineasdeCodigo = LineasdeCodigo.Replace("</Aceptacion>", Estados_Aceptacion);

            // Regresa el código fuente y las líneas de código en un array.
            string[] miArray = new string[] { sourceCode, LineasdeCodigo };

            return miArray;
        }

        private static string getColor()
        {
            // Elige un color aleatorio de una lista.
            List<string> colors = new List<string>
            {
                "ConsoleColor.Blue", "ConsoleColor.DarkCyan",
                "ConsoleColor.Black", "ConsoleColor.Blue"
            };
            var random = new Random();
            int index = random.Next(colors.Count);

            return colors[index];
        }

        private static string getFistPositionsWithCharacters(List<Token> tokens)
        {
            // Devuelve las primeras posiciones de caracteres de tokens.
            string result = "";
            foreach (var token in tokens)
            {
                if (result != "")
                {
                    result += " , ";
                }
                result += $"{{ {token.TokenNumber}, new List<char> {{ {getFormatedCharactersFromList(token.FirstPositions)} }} }}";
            }

            return result;
        }

        private static string getLastPositionsWithCharacters(List<Token> tokens)
        {
            // Devuelve las últimas posiciones de caracteres de tokens.
            string result = "";
            foreach (var token in tokens)
            {
                if (result != "")
                {
                    result += " , ";
                }
                result += $"{{ new List<char> {{ {getFormatedCharactersFromList(token.LastPositions)} }}, {token.TokenNumber} }}";
            }

            return result;
        }

        // Convierte una lista de caracteres en una cadena formateada para su uso posterior.
        private static string getFormatedCharactersFromList(List<char> list)
        {
            string output = "";

            for (int i = 0; i < list.Count; i++)
            {
                // Añade cada carácter con comillas, o usa un código especial para las comillas simples.
                if (list[i] != '\'')
                {
                    output += $"'{list[i]}'";
                }
                else
                {
                    output += "(char) 39";
                }

                // Añade comas entre caracteres, excepto después del último.
                if (i != list.Count - 1)
                {
                    output += ",";
                }
            }

            return output;
        }

        // Devuelve una cadena que representa los estados de aceptación.
        private static string getAcceptedStates(TransitionT transitions)
        {
            string output = "";

            for (int i = 0; i < transitions.states.Count; i++)
            {
                // Agrega el estado a la cadena si es un estado de aceptación.
                if (transitions.states[i].Contains(transitions._followTable.nodes.Count - 1))
                {
                    output += (output == "") ? $"Estado=={i}" : $" || Estado=={i}";
                }
            }

            return output;
        }

        // Crea un diccionario que mapea los índices de estados a si son estados de aceptación.
        private static Dictionary<int, bool> getAcceptedStatesDictionary(TransitionT transitions)
        {
            Dictionary<int, bool> acceptedStates = new Dictionary<int, bool>();

            for (int i = 0; i < transitions.states.Count; i++)
            {
                acceptedStates.Add(i, transitions.states[i].Contains(transitions._followTable.nodes.Count - 1));
            }

            return acceptedStates;
        }

        // Devuelve una cadena que mapea palabras reservadas a sus valores de token.
        private static string getReservedValues(List<Classes.Action> words)
        {
            string output = "";

            foreach (var item in words)
            {
                foreach (var token in item.ActionValues)
                {
                    // Formatea y añade cada palabra reservada y su valor de token a la salida.
                    output += (output == "")
                        ? $"{{ \"{token.Value.ToUpper()}\" , {token.Key} }}"
                        : $" , {{ \"{token.Value.ToUpper()}\" , {token.Key} }}";
                }
            }

            return output;
        }

        // Devuelve una cadena con todas las referencias a tokens especiales.
        private static string getReferences(Dictionary<int, string> references)
        {
            string output = "";

            foreach (var item in references)
            {
                output += (output == "") ? $"{item.Key}" : $",{item.Key}";
            }

            return output;
        }

        // Convierte una lista de estados en un diccionario que mapea su representación como cadena a su índice.
        private static Dictionary<string, int> getDictionaryOfStates(List<List<int>> states)
        {
            Dictionary<string, int> statesDictionary = new Dictionary<string, int>();

            for (int i = 0; i < states.Count; i++)
            {
                statesDictionary.Add(getStringList(states[i]), i);
            }

            return statesDictionary;
        }

        // Compara dos colecciones para ver si tienen los mismos elementos con la misma frecuencia.
        private static bool listsAreEqual<T>(ICollection<T> a, ICollection<T> b)
        {
            if (a.Count != b.Count)
            {
                return false;
            }

            Dictionary<T, int> d = new Dictionary<T, int>();
            foreach (T item in a)
            {
                if (d.TryGetValue(item, out int c))
                {
                    d[item] = c + 1;
                }
                else
                {
                    d.Add(item, 1);
                }
            }

            foreach (T item in b)
            {
                if (d.TryGetValue(item, out int c))
                {
                    if (c == 0)
                    {
                        return false;
                    }
                    else
                    {
                        d[item] = c - 1;
                    }
                }
                else
                {
                    return false;
                }
            }

            return d.Values.All(v => v == 0);
        }

        // Convierte una lista de enteros en una cadena separada por comas y ordenada.
        private static string getStringList(List<int> list)
        {
            list.Sort();
            return string.Join(",", list);
        }

        // Crea una declaración if para una transición y retorna su bloque de código.
        private static string createIFstatement(Transition transition, Dictionary<string, int> states, Dictionary<string, string[]> sets)
        {
            if (transition.nodes.Count > 0)
            {
                return $"if({getTransitionBoolStatement(transition, sets)})\r\n{{\r\nEstado = {getStateNumber(transition.nodes, states)};\r\n}}\r\n";
            }
            else
            {
                return "";
            }
        }

        // Obtiene el número de estado para una lista de estados actuales.
        private static string getStateNumber(List<int> actualState, Dictionary<string, int> states)
        {
            return states[getStringList(actualState)].ToString();
        }

        // Genera la condición booleana para una transición, maneja rangos y caracteres individuales.
        private static string getTransitionBoolStatement(Transition transition, Dictionary<string, string[]> sets)
        {
            if (transition.symbol.Length > 1) // Es un conjunto
            {
                string[] values = sets[transition.symbol];
                string output = "";

                foreach (var item in values)
                {
                    output += (output == "") ? "" : "||";
                    if (item.Contains(','))
                    {
                        string[] limits = item.Split(',');
                        output += $" (actualChar >= {limits[0].Trim()} && actualChar <= {limits[1].Trim()}) ";
                    }
                    else
                    {
                        output += $" actualChar == {item.Trim()} ";
                    }
                }

                return output;
            }
            else if (transition.symbol.Length == 1)// Es un solo carácter
            {
                if (transition.symbol != "'")
                {
                    return $"actualChar == '{transition.symbol}'";
                }
                else
                {
                    return "actualChar == 39";
                }
            }
            else
            {
                throw new Exception("Se ha intentado leer un set sin valor.");
            }
        }



















        private static string getTransitions(TransitionT transitions, Dictionary<string, string[]> sets)
        {
            // Genera el código de transición para cada estado del autómata.
            string output = "";

            Dictionary<string, int> states = getDictionaryOfStates(transitions.states);
            Dictionary<int, bool> isAcceptedState = getAcceptedStatesDictionary(transitions);

            // Procesa cada estado para generar su código.
            for (int i = 0; i < transitions.states.Count; i++)
            {
                bool firstIf = true;

                // Empieza a construir el caso para este estado.
                string actualCase = $"\r\ncase {i}:\r\n";

                // Añade las transiciones de este estado.
                foreach (var item in transitions.transitions[i])
                {
                    if (item.nodes.Count > 0)
                    {
                        actualCase += firstIf ? "" : "else ";
                        actualCase += createIFstatement(item, states, sets);
                        firstIf = false;
                    }
                }

                // Decide si el estado es de aceptación y ajusta la lógica de salida.
                if (actualCase.Contains("if"))
                {
                    if (isAcceptedState[i] && i != 0) // Evita que el primer estado sea de aceptación.
                    {
                        actualCase += "else\r\n{\r\ngoto Valido;\r\n}\r\n";
                    }
                    else
                    {
                        actualCase += "else\r\n{\r\ngoto Error;\r\n}\r\n";
                    }
                }
                else
                {
                    if (isAcceptedState[i])
                    {
                        actualCase += "\r\ngoto Valido;\r\n";
                    }
                    else
                    {
                        actualCase += "\r\ngoto Error;\r\n";
                    }
                }

                // Finaliza el caso para este estado.
                actualCase += $"break;\r\n";
                actualCase = actualCase.Replace("\r\n", "\r\n                        ");

                output += actualCase;
            }

            return output;
        }
    }
}
