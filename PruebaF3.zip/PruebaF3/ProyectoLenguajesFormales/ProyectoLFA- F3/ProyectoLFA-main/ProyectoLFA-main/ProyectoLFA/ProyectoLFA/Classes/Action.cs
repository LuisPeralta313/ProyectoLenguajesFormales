﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ProyectoLFA.Classes
{
    public class Action
    {

        public string ActionName;
        public Dictionary<int, string> ActionValues = new Dictionary<int, string>();
    }
}
