﻿import time

def get_stack(input_string):
    # Invierte la cadena para simular una pila, permitiendo el análisis desde el final hacia el principio.
    return list(reversed(input_string))

def error():
    # Imprime un mensaje de error cuando una cadena no coincide con ningún patrón de token válido.
    print("\nError: La cadena no es válida")

def valido(token):
    # Imprime el token y su correspondiente número de token llamando a get_token_number.
    print("\n" + token + " » " + str(get_token_number(token)))
    return ""

def get_token_number(text):
    # Esta función determina el número de token basado en el primer y último carácter del texto.
    first_character_from_text = text[0]
    last_character_from_text = text[-1]

character_token_first = {
    # Lugar para definir los caracteres que pueden aparecer al inicio de un token.
    # Es necesario completarlo con los valores específicos para los tokens definidos.
</ FirstPos >
}

character_token_last = {
    # Lugar para definir los caracteres que pueden aparecer al final de un token.
    # Es necesario completarlo con los valores específicos para los tokens definidos.
</ LastPos >
}

reservadas_values = {
    # Lugar para definir los valores de las palabras reservadas.
    # Es necesario completarlo con los valores específicos para las palabras reservadas.
</ Reservadas >
}

tokens_con_referencia = [
    # Lista para definir los tokens que tienen una referencia especial.
    # Es necesario completarlo con los valores específicos para estos tokens.
</ Referencias >
]

    for key, value in character_token_last.items():
        if last_character_from_text in key and first_character_from_text in character_token_first.get(value, []):
            if value in tokens_con_referencia:
if text.upper() in reservadas_values:
return reservadas_values[text.upper()]
                return value
    return 0

def analizar_texto(input_stack):
    # Analiza la cadena de texto a partir de la pila de entrada, cambiando estados según las reglas definidas.
    estado = 0
    actual_text = ""

    while input_stack:
        actual_text = actual_text.strip()
        actual_char = input_stack.pop()

        if actual_char != ' ' and actual_char != chr(0):
            if estado == 0:
                if ord('0') <= ord(actual_char) <= ord('9'):
                    estado = 1
                elif actual_char == '=':
                    estado = 2
                elif actual_char == ':':
                    estado = 3
                elif(ord('A') <= ord(actual_char) <= ord('Z')) or(ord('a') <= ord(actual_char) <= ord('z')) or actual_char == '_':
                    estado = 4
                else:
                    error()
                    return
            elif estado == 1:
                if not(ord('0') <= ord(actual_char) <= ord('9')):
                    if actual_text:
                        actual_text = valido(actual_text)
                    estado = 0
                    input_stack.append(actual_char)
                    actual_char = ' '
            elif estado == 2:
                if actual_text:
                    actual_text = valido(actual_text)
                estado = 0
                input_stack.append(actual_char)
                actual_char = ' '
            elif estado == 3:
                if actual_char == '=':
                    estado = 2
                else:
                    error()
                    return
            elif estado == 4:
                if not((ord('0') <= ord(actual_char) <= ord('9')) or(ord('A') <= ord(actual_char) <= ord('Z')) or(ord('a') <= ord(actual_char) <= ord('z')) or actual_char == '_'):
                    if actual_text:
                        actual_text = valido(actual_text)
                    estado = 0
                    input_stack.append(actual_char)
                    actual_char = ' '
            actual_text += actual_char

        else:
            if actual_text and(estado == 1 or estado == 2 or estado == 4):
                actual_text = valido(actual_text)
            else:
                error()
            return

def main():
    # Bucle principal que solicita al usuario ingresar cadenas para analizar y muestra el resultado del análisis.
    while True:
        print("\nEscriba la cadena para analizar: ", end = "")
        input_text = input()
        input_stack = get_stack(input_text)

        print("\nAnalizando", end = "")
        time.sleep(0.3)
        print(".", end = "")
        time.sleep(0.3)
        print(".", end = "")
        time.sleep(0.8)
        print(".")

        try:
            analizar_texto(input_stack)
        except Exception as e:
            print("\nError: " + str(e))

        print("\nPresiona cualquier tecla para continuar.")
        input()
        print()

if __name__ == "__main__":
    main()
